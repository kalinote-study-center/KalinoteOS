/* �ػ� */
#include "../bootpack.h"

void cmd_shutdown(void){
	/* �ػ� */
	asm_shutdown();
}
